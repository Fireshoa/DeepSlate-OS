return {
    appName = "App Browser",
    hidden = false
}