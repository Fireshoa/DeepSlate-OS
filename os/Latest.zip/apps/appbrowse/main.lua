local window = os.newWindow("App Browser", 40, 10)

local scroll = window:addScrollableFrame()
    :setPosition(1, 2)
    :setSize(40, 9)
    :setBackground(os.theme.menuBg)

local function appendapp(appName, app, ypos)
    scroll:addButton()
        :setPosition(2, ypos)
        :setSize(7, 1)
        :setText("Run >")
        :setBackground(os.theme.button)
        :setForeground(os.theme.text)
        :onClick(function()
            os.runApp(app)
            window:disable()
            window:remove()
        end)

    scroll:addLabel()
        :setPosition(10, ypos)
        :setText(appName)
        :setForeground(os.theme.text)
end

local appFolders = fs.list("apps")
local count = 0

for _, name in ipairs(appFolders) do
    if fs.isDir("apps/" .. name) and fs.exists("apps/" .. name .. "/main.lua") then
        local meta = {}
        if fs.exists("apps/" .. name .. "/meta.lua") then
            meta = dofile("apps/" .. name .. "/meta.lua")
        end
        if meta.hidden ~= nil and not meta.hidden then
            count = count + 1
            appendapp(meta.appName or name, name, (count - 1) + 1)
        end
    end
end