local window = os.newWindow("Run", 20, 4, false, false)

local input = window:addInput()
    :setDefaultText("App name")
    :setPosition(10,2)
    :setSize(10,1)

local err = window:addLabel()
    :setText("")
    :setPosition(2,3)

window:addButton()
    :setText("Run >")
    :setPosition(2,2)
    :setSize(7,1)
    :setBackground(os.theme.button)
    :onClick(function()
        local value = input:getValue()
        if value ~= "" then
            if os.appExists(value) then
                input:setValue("")
                os.runApp(value)
                window:disable()
                window:remove()
            else
                err:setText("App does not exist")
            end
        else
            err:setText("Input an app name")
        end
    end)
    