local window = os.newWindow("DS Notepad", 30, 10, false, false)

local path = window:addInput()
    :setValue("documents/")
    :setPosition(2,2)
    :setSize(28, 1)
    :setForeground(os.theme.text)
    :setBackground(os.theme.button)

window:addButton()
    :setText("Edit")
    :setPosition(2,3)
    :setSize(28, 1)
    :setForeground(os.theme.text)
    :setBackground(os.theme.button)
    :onClick(function()
        local value = path:getValue()
        local dir = "apps/edit/editor.lua"
        if fs.exists(dir) then
            window:disable()
            window:remove()
            _G.argPass = value
            dofile(dir)
        end
    end)