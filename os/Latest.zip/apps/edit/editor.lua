local path = _G.argPass
_G.argPass = nil

local window = os.newWindow("DS Notepad", 40, 10, true, false)

local text = window:addTextfield()
    :setPosition(2,4)
    :setSize("parent.w-2", "parent.h-4")
    :setBackground(os.theme.button)
    :setForeground(os.theme.text)

if fs.exists(path) then
    local file = fs.open(path, "r")
    text:clear()
    local line = file.readLine()
    while line do
        text:addLine(line)
        line = file.readLine()
    end
    file:close()
end

window:addButton()
    :setPosition(2,2)
    :setSize(6,1)
    :setText("Save")
    :setBackground(os.theme.button)
    :setForeground(os.theme.text)
    :onClick(function()
        local file = fs.open(path, "w")
        file.write(table.concat(text:getLines(), "\n"))
        file:close()
    end)