return {
    appName = "Edit",
    hidden = false
}
