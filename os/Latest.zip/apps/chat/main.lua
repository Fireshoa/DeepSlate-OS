local window = os.newWindow("Chat", 40, 12)

local input, rmcode, log

window:addLabel()
    :setBackground(colors.white)
    :setForeground(colors.red)
    :setText("I am unsure if this app works.\nIt hasnt been tested.")
    :setPosition(1,11)

peripheral.find("modem", rednet.open)
if rednet.isOpen() then
    rmcode = window:addInput("roomInput")
        :setDefaultText("Room...")
        :setPosition(2,2)
        :setSize(38,1)

    input = window:addInput("msgInput")
        :setDefaultText("Msg...")
        :setPosition(2,9)
        :setSize(10,1)

    window:addButton()
        :setText("^")
        :setPosition(13,9)
        :setSize(3,1)
        :setBackground(os.theme.button)
        :onClick(function()
            local room = rmcode:getValue()
            if room == "" then room = "Public" end
            
            rednet.broadcast({code = room, msg = input:getValue()}, "DSOS_CHAT_PROTO")
            input:setValue("") -- Clear the box after sending
        end)
        
    log = window:addLabel("chatLog")
        :setText("Waiting...")
        :setPosition(2,4)
        :setBackground(os.theme.button)
        :setSize(38,4)
else
    window:addLabel()
        :setText("No Modem Found!")
        :setPosition(2,2)
        :setForeground(colors.red)
end

-- This only runs if the window is open
window:onEvent(function(self, event, sender, message, protocol)
    -- Check if log exists (prevents crash if no modem)
    if log and event == "rednet_message" and protocol == "DSOS_CHAT_PROTO" then
        local currentRoom = rmcode:getValue()
        if currentRoom == "" then currentRoom = "Public" end

        if type(message) == "table" and message.code == currentRoom then
            
            log:setText(sender .. ": " .. (message.msg or ""))
        end
    end
end)