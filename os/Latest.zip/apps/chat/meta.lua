return {
    appName = "Chat",
    hidden = true
}