local window = os.newWindow("Themes", nil, nil, false)

local color = window:addInput()
    :setPosition(2,2)
    :setSize(8,1)

local buttons = window:addButton()
    :setText("Buttons")
    :setPosition(2,3)
    :setSize(8,1)
    :setBackground(os.theme.button)
    :onClick(function(self)
        local col = color:getValue()
        if type(colors[col]) == "number" then
            os.theme.button = colors[col]
            self:setBackground(os.theme.button)
        end
        os.saveTheme()
    end)

local menus = window:addButton()
    :setText("Menus")
    :setPosition(2,4)
    :setSize(8,1)
    :setBackground(os.theme.menuBg)
    :onClick(function(self)
        local col = color:getValue()
        if type(colors[col]) == "number" then
            os.theme.menuBg = colors[col]
            self:setBackground(os.theme.menuBg)
            os.saveTheme()
        end
    end)

local bg = window:addButton()
    :setText("BG")
    :setPosition(2,5)
    :setSize(8,1)
    :setBackground(os.theme.osBg)
    :onClick(function(self)
        local col = color:getValue()
        if type(colors[col]) == "number" then
            os.theme.osBg = colors[col]
            self:setBackground(os.theme.osBg)
            os.saveTheme()
        end
    end)
    
local bg = window:addButton()
    :setText("Text")
    :setPosition(2,6)
    :setSize(8,1)
    :setBackground(os.theme.button)
    :setForeground(os.theme.text)
    :onClick(function(self)
        local col = color:getValue()
        if type(colors[col]) == "number" then
            os.theme.text = colors[col]
            self:setBackground(os.theme.button)
            self:setForeground(os.theme.text)
            os.saveTheme()
        end
    end)