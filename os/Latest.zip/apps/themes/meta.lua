return {
    appName = "Customize",
    hidden = false
}